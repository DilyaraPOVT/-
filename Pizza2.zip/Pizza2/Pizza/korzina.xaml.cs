﻿
using Pizza.ViewModels;
using Xamarin.Forms;


namespace Pizza
{
    public partial class SettingsPage : ContentPage
    {

        //private static readonly HttpClient client = new HttpClient();
        ////WebRequest request = WebRequest.Create("https://localhost:5001/Home/Hello");
        //private readonly string helloUrl = "http://localhost:8999/Home/Hello";
        ////  private readonly string 

        
        ChatViewModel viewModel;

        public SettingsPage()
        {
           // this.BindingContext = new ChatViewModel();
            InitializeComponent();
            viewModel = new ChatViewModel();
            this.BindingContext = viewModel;
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await viewModel.Connect();
        }

        protected override async void OnDisappearing()
        {
            base.OnDisappearing();
            await viewModel.Disconnect();
        }

    }
}
//async void Button_Clicked(object sender, EventArgs e)
//{
//   // bool resp = false;

//    Data dt = new Data()
//    {
//        Name = Convert.ToString(userName.Text),
//        Sername = Convert.ToString(LName.Text),
//        Number = Convert.ToString(Phone.Text)
//    };
//    string jsonSt = await Task.Factory.StartNew(() => JsonConvert.SerializeObject(userName.Text));

//    //string jsonStr = JsonConvert.SerializeObject(dt);
//    //Dictionary<string, string> dict = new Dictionary<string, string>()
//    //{
//    //    {"s", jsonSt }
//    //};
//    //FormUrlEncodedContent form = new FormUrlEncodedContent(dict);
//    //HttpResponseMessage response = await client.PostAsync(helloUrl, form);
//    //string result = await response.Content.ReadAsStringAsync();
//    //await DisplayAlert("ffb", result, "dg");



//    //string jsonSt = await Task.Factory.StartNew(() => JsonConvert.SerializeObject(userName.Text));
//    WebRequest request = WebRequest.Create("https://localhost:8999/Home/Hello");
//    request.Method = "POST";
//    string query = $"name={jsonSt}";
//    byte[] byteMsg = Encoding.UTF8.GetBytes(query);
//    request.ContentType = "application/x-www-form-urlencoded";
//    request.ContentLength = byteMsg.Length;
//    using (Stream stream = await request.GetRequestStreamAsync())
//    {
//        await stream.WriteAsync(byteMsg, 0, byteMsg.Length);

//    }
//    WebResponse response = await request.GetResponseAsync();
//    string answer = null;
//    using (Stream s = response.GetResponseStream())
//    {
//        using (StreamReader sR = new StreamReader(s))
//        {
//            answer = await sR.ReadToEndAsync();
//            //  await DisplayAlert("Уведомле ние", "Ваш заказ уже готовится", "Ок");

//        }

//    }

//    //async Task DisplayAlert(string title, string message, string cancel)
//    //{
//    //   await DisplayAlert("Уведомление", "Ваш заказ уже готовится", "Ок");

//    //}
//    response.Close();
//    //async Task DisplayAlert(string title, string message, string cancel)
//    //{
//    //    await DisplayAlert("Уведомление", "Ваш заказ уже готовится", "Ок");

//    //}
//    //while (resp)
//    //{
//    //await DisplayAlert("Уведомление", "Ваш заказ уже готовится", "Ок");

//    //}


//}
//private string pizzaName;
//private string components;
//private string pizzaPrice;

//public string PizzaName
//{
//    get { return pizzaName; }
//    set
//    {
//        if(pizzaName !=value)
//        {
//            pizzaName = value;
//            OnPropertyChanged("PizzaName");
//        }
//    }
//}
//public string Components
//{
//    get { return components; }
//    set
//    {
//        if (components != value)
//        {
//            components = value;
//            OnPropertyChanged("Components");
//        }
//    }
//}
//public string PizzaPrice
//{
//    get { return pizzaPrice; }
//    set
//    {
//        if (pizzaPrice != value)
//        {
//            pizzaPrice = value;
//            OnPropertyChanged("PizzaPrice");
//        }
//    }
//}
//public event PropertyChangedEventHandler PropertyChanged;
//public void OnPropertyChanged(string prop = "")
//{
//    if (PropertyChanged != null)
//        PropertyChanged(this, new PropertyChangedEventArgs(prop));
//}

















//        private async void Button_Clicked(object sender, EventArgs e)
//        {
//            // bool resp = false;

//            Data dt = new Data()
//            {
//                Name = Convert.ToString(userName.Text),
//                Sername = Convert.ToString(LName.Text),
//                Number = Convert.ToString(Phone.Text)
//            };
//            string jsonSt = await Task.Factory.StartNew(() => JsonConvert.SerializeObject(userName.Text));

//            //string jsonStr = JsonConvert.SerializeObject(dt);
//            //Dictionary<string, string> dict = new Dictionary<string, string>()
//            //{
//            //    {"s", jsonSt }
//            //};
//            //FormUrlEncodedContent form = new FormUrlEncodedContent(dict);
//            //HttpResponseMessage response = await client.PostAsync(helloUrl, form);
//            //string result = await response.Content.ReadAsStringAsync();
//            //await DisplayAlert("ffb", result, "dg");



//            //string jsonSt = await Task.Factory.StartNew(() => JsonConvert.SerializeObject(userName.Text));
//            WebRequest request = WebRequest.Create("https://localhost:8999/Home/Hello");
//            request.Method = "POST";
//            string query = $"userName={jsonSt}";
//            byte[] byteMsg = Encoding.UTF8.GetBytes(query);
//            request.ContentType = "application/x-www-form-urlencoded";
//            request.ContentLength = byteMsg.Length;
//            using (Stream stream = await request.GetRequestStreamAsync())
//            {
//                await stream.WriteAsync(byteMsg, 0, byteMsg.Length);

//            }

//            string answer = null;
//            WebResponse response = await request.GetResponseAsync();



//            using (Stream s = response.GetResponseStream())
//            {
//                using (StreamReader sR = new StreamReader(s))
//                {
//                    answer = await sR.ReadToEndAsync();
//                    //  await DisplayAlert("Уведомле ние", "Ваш заказ уже готовится", "Ок");
//                    Console.WriteLine(sR.ReadToEndAsync());

//                }

//            }




//            //async Task DisplayAlert(string title, string message, string cancel)
//            //{
//            //   await DisplayAlert("Уведомление", "Ваш заказ уже готовится", "Ок");

//            //},
//           response.Close();
//            //async Task DisplayAlert(string title, string message, string cancel)
//            //{
//            //    await DisplayAlert("Уведомление", "Ваш заказ уже готовится", "Ок");

//            //}
//            //while (resp)
//            //{
//           string hellostr = await Task.Factory.StartNew(() => JsonConvert.DeserializeObject<string>(answer));
//            await DisplayAlert("Уведомление", "Ваш заказ уже готовится", "Ок");

//            //}


//        }
//    }
//}

