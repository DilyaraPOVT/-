﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pizza.Models
{
    public class MessageData
    {
        public string Message { get; set; }
        public string User { get; set; }
    }
}
