﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Sockets;
using System.Text;
using Xamarin.Forms;

namespace Pizza
{
    public class SettingsPageCS : SchedulePage
    {
        //private static readonly HttpClient client = new HttpClient();
        public SettingsPageCS()
        {
            var button = new Button
            {
                Text = "Отправить",
                VerticalOptions = LayoutOptions.CenterAndExpand
            }; 
            //  button.Clicked += Button_Clicked;
            IconImageSource = "settings.png";
            Title = "Корзина";
            // Content = new StackLayout
            Content = new StackLayout

            {
                Children = {
                    new Label
                    {
                        Text = "Введите данные для заказа",
                        HorizontalOptions = LayoutOptions.Center,
                        VerticalOptions = LayoutOptions.CenterAndExpand
                    },
                    //new Entry 
                    //{
                    //    Text = "{Binding text}"                                   
                    //},
                    //new FlexLayout
                    //{
                    //    if switch1
                    //},
                    button

                }
            };
        }
        private async void Button_Clicked(object sender, EventArgs e)
        {
            //await Navigation.PushAsync(MainPage());
            await DisplayAlert("Уведомление", "Ваш заказ уже готовится!", "ОK");

        }

    }
}