﻿using System;
using Xamarin.Forms;

namespace Pizza
{
	public class SchedulePageCS : ContentPage
	{
		public SchedulePageCS()
		{
			var button = new Button
			{
				Text = "Upcoming Appointments",
				VerticalOptions = LayoutOptions.CenterAndExpand
			};
			button.Clicked += OnUpcomingAppointmentsButtonClicked;
			//var switchs1 = new SwitchCell
			//{

			//};
			//var switchs2 = new Switch();
			//var switchs 1 = new Switch();
			//var switchs2 = new Switch();

			//if (switchs1.IsToggled)

			// Switch[] switchs = new Switch[]
			//{
			//switchs1, switchs2
			//};
			//foreach ( var Switch in switchs)
			//for(int i=0; i<switchs.Length; i++)
			//{
			//if (switchs1.IsToggled || switchs2.IsToggled)
			//	Console.WriteLine();

			//}

			Content = new StackLayout
			{
				Children = {
					new Label {
						Text = "This week's appointments go here",
						HorizontalOptions = LayoutOptions.Center,
						VerticalOptions = LayoutOptions.CenterAndExpand
					},
					//new FlexLayout
					//{
					//	new Label
					//	{
					//		Text = "Th"
					//	},
					//	switchs1
					

					//	new Label
					//	{
					//		Text = "Tdfgfh"
					//	},
					//	switchs2
					//},
					button
					//switchs1,
					//switchs2

				}
			};
		}

		async void OnUpcomingAppointmentsButtonClicked(object sender, EventArgs e)
		{
			await Navigation.PushAsync(new UpcomingAppointmentsPage());
		}
		//async void OnButtonClicked(object sender, EventArgs e)
		//{
		//	await Navigation.PushAsync(new UpcomingAppointmentsPage());
		//}
		//async void OnSaveButtonClicked(object sender, EventArgs e)
		//{
		//	await Navigation.PopAsync();

		//}
	}
}
