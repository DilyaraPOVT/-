﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using Xamarin.Forms;

namespace Pizza
{
    public partial class SchedulePage : ContentPage
    {
        //  private bool Switch1;

        //protected internal ObservableCollection<Class2> Pizzas { get; set; }

        //static private readonly Switch switchs1;
        //static private readonly Switch switchs2;
        // Switch[] switchs = new Switch[]
        //  {
        //        switchs1, switchs2
        //  }; 
        public SchedulePage()
        {
            InitializeComponent();
            //Pizzas = new ObservableCollection<Class2>
            //{
            //    new Class2 {PizzaName="iPhone 7", Components="Apple", PizzaPrice=52000, Switch1="false"},
            //    new Class2 {PizzaName="Galaxy S8", Components="Samsung", PizzaPrice=50000, Switch2="false"},
            //    new Class2 {PizzaName="LG G6", Components="LG", PizzaPrice=45000, Switch3="false"},
            //    new Class2 {PizzaName="Huawei P10", Components="Huawei", PizzaPrice=35000, Switch4="false"}
            //};
            //phonesList.BindingContext = Pizzas;
        }




        //// обработчик выбора элемента в списке
        //private async void OnListViewItemSelected(object sender, SelectedItemChangedEventArgs args)
        //{
        //    // Получаем выбранный элемент 
        //    Class2 selectedPhone = args.SelectedItem as Class2;
        //    if (Switch1)
        //    {
        //        // Снимаем выделение
        //        phonesList.SelectedItem = null;
        //        // Переходим на страницу редактирования элемента 
        //        await Navigation.PushAsync(new SettingsPage(selectedPhone));
        //    }
        //}
        

        async void OnUpcomingAppointmentsButtonClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new UpcomingAppointmentsPage());
        }

        //async void OnSaveButtonClicked(object sender, EventArgs e)
        //{
        //    //Switch[] switchs = new Switch[]
        //    //{
        //    //    switchs1, switchs2
        //    //};
        //    ////var switchs2 = new Switch();
        //    //// var note = Text;
        //    //for (int i = 0; i < switchs.Length; i++)
        //    //{
        //    //    if (switchs1.IsToggled || switchs2.IsToggled)
        //    //    // if (string.IsNullOrWhiteSpace(note.Filename))
        //    //    {
        //    //        // Save
        //    //        var filename = Path.Combine(App.FolderPath, $"{Path.GetRandomFileName()}.notes.txt");
        //    //        //File.WriteAllText(filename, switchs);
        //    //    }
        //    //}
        //    //else
        //    //{
        //    //    // Update 
        //    //    File.WriteAllText(note.Filename, note.Text);
        //    //}

        //    await Navigation.PopAsync();
        //}
    }
}

